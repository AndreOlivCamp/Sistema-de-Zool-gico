package zoologico.animais;

public abstract class Animal {
    private String nome;
    private String especie;
    private int idade;

    public Animal(String nome, String especie, int idade) {
        this.nome = nome;
        this.especie = especie;
        this.idade = idade;
    }

    public abstract void emitirSom();

    public void exibirInfo() {
        System.out.println(nome + " (" + especie + "), " + idade + " anos");
    }

    public String getNome() { return nome; }
    public String getEspecie() { return especie; }
    public int getIdade() { return idade; }
}