package zoologico.animais;

public class Mamifero extends Animal {

    public Mamifero(String nome, String especie, int idade) {
        super(nome, especie, idade);
    }

    @Override
    public void emitirSom() {
        System.out.println(getNome() + " ruge/late/mia dependendo da espécie.");
    }
}