package zoologico.usuarios;

import zoologico.animais.Mamifero;
import zoologico.Re
cinto;
public class Main {
    public static void main(String[] args) {
        Mamifero leao = new Mamifero("Simba", "Leão", 5);
        leao.emitirSom();

        Recinto savana = new Recinto("Savana");
        savana.adicionarAnimal(leao);
        savana.listarAnimais();

        Visitante v = new Visitante("André", "andre@email.com");
        v.exibirInfo();
    }
}