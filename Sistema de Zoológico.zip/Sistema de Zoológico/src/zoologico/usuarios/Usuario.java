package zoologico.usuarios;

public abstract class Usuario {
    private String nome;
    private String email;

    public Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
    }

    public abstract String getTipo();

    public void exibirInfo() {
        System.out.println(nome + " (" + getTipo() + ") - " + email);
    }
}