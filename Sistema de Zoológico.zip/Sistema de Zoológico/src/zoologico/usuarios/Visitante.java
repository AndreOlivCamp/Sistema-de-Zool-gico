package zoologico.usuarios;

public class Visitante extends Usuario {

    public Visitante(String nome, String email) {
        super(nome, email);
    }

    @Override
    public String getTipo() {
        return "Visitante";
    }
}