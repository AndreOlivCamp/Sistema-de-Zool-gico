package zoologico;

import zoologico.animais.Animal;
import java.util.ArrayList;
import java.util.List;

public class Recinto {
    private String nome;
    private List<Animal> animais = new ArrayList<>();

    public Recinto(String nome) {
        this.nome = nome;
    }

    public void adicionarAnimal(Animal a) {
        animais.add(a);
        System.out.println(a.getNome() + " adicionado ao recinto " + nome);
    }

    public void listarAnimais() {
        System.out.println("Animais em " + nome + ":");
        for (Animal a : animais) {
            a.exibirInfo();
        }
    }
}